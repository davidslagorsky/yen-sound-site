import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { supabase } from "../supabase";

export default function Press() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchPosts() {
      const { data, error } = await supabase
        .from("press_posts")
        .select("id, title, artist, cover_url, date, excerpt, slug")
        .order("date", { ascending: false });
      if (!error && data) setPosts(data);
      setLoading(false);
    }
    fetchPosts();
  }, []);

  return (
    <>
      <Helmet>
        <title>Press — YEN SOUND</title>
        <meta name="description" content="Stories, features and updates from YEN SOUND artists." />
        <meta property="og:title" content="Press — YEN SOUND" />
        <meta property="og:description" content="Stories, features and updates from YEN SOUND artists." />
      </Helmet>

      <div style={styles.page}>
        <h1 style={styles.pageTitle}>PRESS</h1>

        {loading && <p style={styles.empty}>Loading...</p>}

        {!loading && posts.length === 0 && (
          <p style={styles.empty}>No posts yet.</p>
        )}

        {!loading && posts.length > 0 && (
          <div style={styles.grid}>
            {posts.map((post) => (
              <Link key={post.id} to={`/press/${post.slug}`} style={styles.cardLink}>
                <article style={styles.card}>
                  {post.cover_url && (
                    <div style={styles.coverWrap}>
                      <img src={post.cover_url} alt={post.title} style={styles.cover} />
                    </div>
                  )}
                  <div style={styles.cardBody}>
                    <p style={styles.cardDate}>{formatDate(post.date)}</p>
                    {post.artist && <p style={styles.cardArtist}>{post.artist}</p>}
                    <h2 style={styles.cardTitle}>{post.title}</h2>
                    {post.excerpt && <p style={styles.cardExcerpt}>{post.excerpt}</p>}
                    <span style={styles.readMore}>Read →</span>
                  </div>
                </article>
              </Link>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

function formatDate(d) {
  if (!d) return "";
  return new Date(d + "T00:00:00").toLocaleDateString("en-GB", {
    day: "2-digit", month: "short", year: "numeric",
  });
}

const styles = {
  page: {
    padding: "80px 24px 80px",
    maxWidth: "1080px",
    margin: "0 auto",
    fontFamily: "'Barlow Condensed', 'Arial Narrow', Arial, sans-serif",
  },
  pageTitle: {
    fontSize: "clamp(42px, 8vw, 90px)",
    fontWeight: 900,
    letterSpacing: "0.12em",
    color: "#fff",
    marginBottom: "48px",
    lineHeight: 1,
  },
  empty: {
    color: "#555",
    fontFamily: "Arial, sans-serif",
    fontSize: "14px",
    letterSpacing: "0.2em",
    textTransform: "uppercase",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
    gap: "1px",
    background: "#1a1a1a",
  },
  cardLink: { textDecoration: "none", color: "#fff" },
  card: {
    background: "#000",
    display: "flex",
    flexDirection: "column",
    cursor: "pointer",
    transition: "background 0.2s",
  },
  coverWrap: {
    width: "100%",
    aspectRatio: "16/9",
    overflow: "hidden",
  },
  cover: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    display: "block",
    transition: "transform 0.5s ease",
  },
  cardBody: { padding: "24px" },
  cardDate: {
    fontSize: "10px",
    letterSpacing: "0.35em",
    textTransform: "uppercase",
    color: "#555",
    marginBottom: "6px",
    fontFamily: "Arial, sans-serif",
  },
  cardArtist: {
    fontSize: "10px",
    letterSpacing: "0.3em",
    textTransform: "uppercase",
    color: "#777",
    marginBottom: "8px",
    fontFamily: "Arial, sans-serif",
  },
  cardTitle: {
    fontSize: "clamp(20px, 3vw, 28px)",
    fontWeight: 700,
    letterSpacing: "0.03em",
    lineHeight: 1.1,
    marginBottom: "10px",
    color: "#fff",
  },
  cardExcerpt: {
    fontSize: "13px",
    lineHeight: 1.7,
    color: "#888",
    marginBottom: "16px",
    display: "-webkit-box",
    WebkitLineClamp: 3,
    WebkitBoxOrient: "vertical",
    overflow: "hidden",
    fontFamily: "Arial, sans-serif",
    fontWeight: "normal",
  },
  readMore: {
    fontSize: "11px",
    letterSpacing: "0.25em",
    textTransform: "uppercase",
    color: "#fff",
    borderBottom: "1px solid #333",
    paddingBottom: "2px",
    fontFamily: "Arial, sans-serif",
  },
};
