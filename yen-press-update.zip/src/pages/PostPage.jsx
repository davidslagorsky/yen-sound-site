import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { supabase } from "../supabase";

export default function PostPage() {
  const { slug } = useParams();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    async function fetchPost() {
      const { data, error } = await supabase
        .from("press_posts")
        .select("*")
        .eq("slug", slug)
        .single();
      if (error || !data) setNotFound(true);
      else setPost(data);
      setLoading(false);
    }
    fetchPost();
  }, [slug]);

  if (loading) return <div style={styles.loading}>Loading...</div>;
  if (notFound) return (
    <div style={styles.loading}>
      Post not found. <Link to="/press" style={{ color: "#fff" }}>← Back to Press</Link>
    </div>
  );

  const canonicalUrl = `https://www.yensound.com/press/${post.slug}`;

  return (
    <>
      <Helmet>
        <title>{post.title} — YEN SOUND</title>
        <meta name="description" content={post.excerpt || `${post.title} — YEN SOUND`} />
        <link rel="canonical" href={canonicalUrl} />

        {/* Open Graph */}
        <meta property="og:type" content="article" />
        <meta property="og:title" content={`${post.title} — YEN SOUND`} />
        <meta property="og:description" content={post.excerpt || ""} />
        <meta property="og:url" content={canonicalUrl} />
        {post.cover_url && <meta property="og:image" content={post.cover_url} />}
        <meta property="og:site_name" content="YEN SOUND" />
        {post.date && <meta property="article:published_time" content={post.date} />}

        {/* Twitter */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={`${post.title} — YEN SOUND`} />
        <meta name="twitter:description" content={post.excerpt || ""} />
        {post.cover_url && <meta name="twitter:image" content={post.cover_url} />}

        {/* JSON-LD structured data for Google */}
        <script type="application/ld+json">{JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Article",
          "headline": post.title,
          "description": post.excerpt || "",
          "image": post.cover_url || "",
          "datePublished": post.date || "",
          "author": { "@type": "Organization", "name": "YEN SOUND" },
          "publisher": {
            "@type": "Organization",
            "name": "YEN SOUND",
            "url": "https://www.yensound.com"
          },
          "url": canonicalUrl,
        })}</script>
      </Helmet>

      <article style={styles.page}>
        {/* Back link */}
        <Link to="/press" style={styles.back}>← Press</Link>

        {/* Header */}
        <header style={styles.header}>
          <p style={styles.date}>{formatDate(post.date)}</p>
          {post.artist && <p style={styles.artist}>{post.artist}</p>}
          <h1 style={styles.title}>{post.title}</h1>
          {post.excerpt && <p style={styles.excerpt}>{post.excerpt}</p>}
        </header>

        {/* Cover */}
        {post.cover_url && (
          <div style={styles.coverWrap}>
            <img src={post.cover_url} alt={post.title} style={styles.cover} />
          </div>
        )}

        {/* Body */}
        <div
          className="press-body"
          style={styles.body}
          dangerouslySetInnerHTML={{ __html: post.body || "" }}
        />

        {/* Footer nav */}
        <div style={styles.postFooter}>
          <Link to="/press" style={styles.back}>← All Posts</Link>
        </div>
      </article>
    </>
  );
}

function formatDate(d) {
  if (!d) return "";
  return new Date(d + "T00:00:00").toLocaleDateString("en-GB", {
    day: "2-digit", month: "long", year: "numeric",
  });
}

const styles = {
  page: {
    maxWidth: "720px",
    margin: "0 auto",
    padding: "80px 24px 100px",
    fontFamily: "Arial, sans-serif",
  },
  loading: {
    color: "#555",
    fontFamily: "Arial, sans-serif",
    fontSize: "13px",
    letterSpacing: "0.2em",
    textTransform: "uppercase",
    padding: "120px 24px",
    textAlign: "center",
  },
  back: {
    display: "inline-block",
    fontSize: "11px",
    letterSpacing: "0.3em",
    textTransform: "uppercase",
    color: "#666",
    textDecoration: "none",
    marginBottom: "40px",
    transition: "color 0.2s",
    fontFamily: "Arial, sans-serif",
  },
  header: { marginBottom: "36px" },
  date: {
    fontSize: "10px",
    letterSpacing: "0.35em",
    textTransform: "uppercase",
    color: "#555",
    marginBottom: "8px",
  },
  artist: {
    fontSize: "11px",
    letterSpacing: "0.3em",
    textTransform: "uppercase",
    color: "#777",
    marginBottom: "12px",
    display: "inline-block",
    border: "1px solid #333",
    padding: "4px 10px",
  },
  title: {
    fontFamily: "'Barlow Condensed', 'Arial Narrow', Arial, sans-serif",
    fontSize: "clamp(36px, 7vw, 72px)",
    fontWeight: 900,
    letterSpacing: "0.02em",
    lineHeight: 0.95,
    color: "#fff",
    marginBottom: "16px",
    marginTop: "8px",
  },
  excerpt: {
    fontSize: "16px",
    lineHeight: 1.6,
    color: "#888",
    fontStyle: "italic",
  },
  coverWrap: {
    width: "100%",
    aspectRatio: "16/9",
    overflow: "hidden",
    marginBottom: "48px",
    marginTop: "36px",
  },
  cover: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    display: "block",
  },
  body: {
    fontSize: "16px",
    lineHeight: 1.85,
    color: "rgba(255,255,255,0.72)",
    // Inline styles for children via global CSS in index.css
  },
  postFooter: {
    marginTop: "64px",
    paddingTop: "32px",
    borderTop: "1px solid #1a1a1a",
  },
};
